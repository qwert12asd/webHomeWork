
function fun() {
    var box1 = document.getElementById("hwo");
    var box2 = document.getElementById("hwt");
    box1.style.display = 'inline';
    box2.style.display = 'None';
}


function func() {
    var box2 = document.getElementById("hwo");
    var box1 = document.getElementById("hwt");
    box1.style.display = 'inline';
    box2.style.display = 'None';
}